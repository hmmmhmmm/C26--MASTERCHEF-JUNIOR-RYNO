**Caremel**

- 1 cup caster sugar
- 1/4 cup water

**Custard**

- 3 egg yolks
- 1 egg
- 110g caster sugar
- 250g milk
- 250g thickened cream
- 1 vanilla bean, split lengthways

